# Wisdomark Match Engine

A fast, mobile-first football predictions app. No build step, no dependencies: open `index.html` and it runs.

## Features

- **Matches**: upcoming fixtures across the Premier League, La Liga, Serie A, Bundesliga, Ligue 1 and Champions League, with win/draw/win chances, over 2.5 goals, both teams to score, likely score and minimum odds worth taking.
- **Live**: score and minute tracker that recalculates chances as the match goes on (auto-fills from a public scoreboard feed when reachable).
- **Tables / Results**: league standings and recent results.
- **My data**: upload CSVs from football-data.co.uk, fit team strengths, predict any pairing and back-test against bookmakers.
- **Tools**: stake planner (quarter-Kelly), accumulator checker, bookmaker margin check, bet journal and daily loss limit.
- Light/dark theme and accent colour picker.

## Run locally

```bash
# any static server works
python3 -m http.server 8080
# then open http://localhost:8080
```

Or just double-click `index.html`.

## Project structure

```
index.html   the whole app: markup, styles and script in one file
```

## Deploy on GitHub Pages

1. Create a repository and push these files to the `main` branch.
2. In **Settings > Pages**, set **Source** to **GitHub Actions**.
3. The included workflow (`.github/workflows/pages.yml`) publishes the site on every push.

Netlify, Vercel or any static host also works: just serve the folder.

## Updating the data

Fixtures, tables and results live in the `RAW` object at the top of `index.html`, with a snapshot time in `DATA_AT`. Replace them to refresh the app.

## Disclaimer

Predictions are probabilities, not promises. Betting is for adults (18+) and you can lose money. Only stake what you can afford to lose.

By [Wisdomark](https://wisdomark.netlify.app/).
